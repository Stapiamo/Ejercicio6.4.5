package cl.bootcamp.newsapi.util

class Constants {
    companion object {
        const val BASE_URL = "https://newsapi.org/v2/"
        const val ENDPOINT = "everything"
        const val API_KEY = "21e9e7055177408a815da315f49f1483"  // No incluyas "apiKey=" aquí, se usará en la consulta
    }
}